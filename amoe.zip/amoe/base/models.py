from django.db import models


# Create your models here.
class CrowdFunding(models.Model):
    name = models.CharField(max_length=30, verbose_name="CrowdFunding")
    description = models.TextField(verbose_name='Description')
    rating = models.FloatField(default=0, verbose_name="Rating")
    url = models.URLField(verbose_name="Website Adress")

    class Meta:
        verbose_name = 'Платформа общего финансирования'
        verbose_name_plural = 'Платформы общего финансирования'

    def __str__(self):
        return self.name


class Project(models.Model):
    crowdfunding = models.ForeignKey(CrowdFunding, on_delete=models.CASCADE)
    name = models.CharField(max_length=30, verbose_name="Project Name")
    short_description = models.CharField(max_length=30, verbose_name='Description')
    price = models.IntegerField(default=0, verbose_name="Donation")
    photo = models.ImageField('Photo', upload_to='base/photos', default='', blank=True)

    class Meta:
        verbose_name = 'Проект'
        verbose_name_plural = 'Проекты'
        ordering = ["price"]

    def __str__(self):
        return self.name
