from django.shortcuts import render, get_object_or_404
from base.models import Project

from base.forms import OrderForm

from django.http import HttpResponseRedirect
from django.urls import reverse


# Create your views here.
def home(request):
    projects = Project.objects.all()
    return render(request, 'index.html', {'projects': projects})


def project_detail(request, project_id):
    project = get_object_or_404(Project, id=project_id)
    form = OrderForm(request.POST or None, initial={
        'project': project,
    })

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('{}?sent=True'.format(reverse('project-detail', kwargs={'project_id':project.id})))

    return render(request, 'project_detail.html', {
        'project': project,
        'form': form,
        'sent': request.GET.get('sent', False),
    })
