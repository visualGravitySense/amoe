from django import forms
from base.models import Order
from base.models import Project

class OrderForm(forms.ModelForm):
    project = forms.ModelChoiceField(queryset=Project.objects.all(), widget=forms.HiddenInput)
    class Meta:
        model = Order
        fields = ('project', 'name', 'phone')