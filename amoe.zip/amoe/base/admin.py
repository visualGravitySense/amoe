from django.contrib import admin
from base.models import CrowdFunding, Project, Order

# Register your models here.
admin.site.register(CrowdFunding)
admin.site.register(Project)


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['project', 'name', 'phone', 'date']
