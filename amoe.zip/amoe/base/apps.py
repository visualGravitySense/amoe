from django.apps import AppConfig


class BaseConfig(AppConfig):
    name = 'base'
    verbose_name = 'Платформа общего финансирования'
