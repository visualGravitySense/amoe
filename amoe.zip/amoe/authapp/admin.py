from django.contrib import admin
from authapp.models import CrowdShop

# Register your models here.
admin.site.register(CrowdShop)