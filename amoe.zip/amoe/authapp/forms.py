from django.contrib.auth.models import User
from django import forms
from authapp.models import CrowdShop

class UserForm(forms.ModelForm):
    email = forms.CharField(max_length=100, required=True)
    password = forms.CharField(widget=forms.PasswordInput)
    class Meta:
        model = User
        fields = ('username', 'password', 'first_name', 'last_name', 'email')

class CrowdShopForm(forms.ModelForm):
    class Meta:
        model = CrowdShop
        fields = ('name', 'logo')

