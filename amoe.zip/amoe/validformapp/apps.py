from django.apps import AppConfig


class ValidformappConfig(AppConfig):
    name = 'validformapp'
